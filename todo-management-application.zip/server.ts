import express, { Request, Response, NextFunction } from "express";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "tododb.json");

interface UserData {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

interface ListData {
  id: string;
  userId: string;
  name: string;
  shareToken: string;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
}

interface ItemData {
  id: string;
  listId: string;
  title: string;
  description?: string;
  completed: boolean;
  tags: string[];
  order: number;
  dueDate?: string;
  reminderEmail?: string;
  reminderSent?: boolean;
  createdAt: string;
  updatedAt: string;
}

interface ReminderLogData {
  id: string;
  userId: string;
  todoTitle: string;
  listName: string;
  email: string;
  sentAt: string;
}

interface DB {
  users: UserData[];
  tokens: Record<string, string>; // token -> userId
  lists: ListData[];
  items: ItemData[];
  reminderLogs: ReminderLogData[];
}

// Helpers for Auth and Password Hashing
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString("hex");
}

// Helper to load or initialize DB
function loadDB(): DB {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (err) {
    console.error("Error loading DB, creating fresh DB:", err);
  }

  // Seed default DB
  const demoSalt = generateSalt();
  const demoUser: UserData = {
    id: "user_demo_1",
    name: "Vidya Shree",
    email: "demo@example.com",
    passwordHash: hashPassword("password123", demoSalt),
    salt: demoSalt,
    createdAt: new Date().toISOString(),
  };

  const demoList1: ListData = {
    id: "list_1",
    userId: demoUser.id,
    name: "SDE Assessment Tasks",
    shareToken: "share_sde_assessment_2026",
    isPublic: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const demoList2: ListData = {
    id: "list_2",
    userId: demoUser.id,
    name: "Personal & Ideas",
    shareToken: crypto.randomUUID(),
    isPublic: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const demoItems: ItemData[] = [
    {
      id: "item_1",
      listId: demoList1.id,
      title: "Design Todo Management UI with Tailwind CSS",
      description: "Ensure high contrast, responsive mobile layout, and clear statistics card.",
      completed: true,
      tags: ["urgent", "high priority"],
      order: 0,
      dueDate: new Date().toISOString().split("T")[0],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "item_2",
      listId: demoList1.id,
      title: "Implement Tag Filter and Stats per Todo List",
      description: "Count total, completed, pending, and per-tag items including 'no tag'.",
      completed: true,
      tags: ["urgent"],
      order: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "item_3",
      listId: demoList1.id,
      title: "Generate Unique Share Link for Todo Lists",
      description: "Allow anyone with the public link to view the list.",
      completed: false,
      tags: ["low priority"],
      order: 2,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "item_4",
      listId: demoList1.id,
      title: "Test Mobile Browser Compatibility & Drag Reorder",
      description: "Reorder items smoothly on mobile and desktop views.",
      completed: false,
      tags: ["not important"],
      order: 3,
      dueDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
      reminderEmail: "demo@example.com",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "item_5",
      listId: demoList1.id,
      title: "Refactor code components and prepare project documentation",
      completed: false,
      tags: [],
      order: 4,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];

  const db: DB = {
    users: [demoUser],
    tokens: {},
    lists: [demoList1, demoList2],
    items: demoItems,
    reminderLogs: [],
  };

  saveDB(db);
  return db;
}

function saveDB(db: DB) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving DB:", err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  let db = loadDB();

  // Auth Middleware
  interface AuthenticatedRequest extends Request {
    userId?: string;
  }

  const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Authentication token required" });
    }
    const token = authHeader.split(" ")[1];
    const userId = db.tokens[token];
    if (!userId) {
      return res.status(401).json({ error: "Invalid or expired token" });
    }
    req.userId = userId;
    next();
  };

  // --- AUTH ENDPOINTS ---
  app.post("/api/auth/register", (req: Request, res: Response) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email, and password are required" });
    }

    const normalizedEmail = email.toLowerCase().trim();
    if (db.users.some((u) => u.email === normalizedEmail)) {
      return res.status(400).json({ error: "User with this email already exists" });
    }

    const salt = generateSalt();
    const newUser: UserData = {
      id: "user_" + crypto.randomUUID(),
      name: name.trim(),
      email: normalizedEmail,
      passwordHash: hashPassword(password, salt),
      salt,
      createdAt: new Date().toISOString(),
    };

    // Create default list for new user
    const defaultList: ListData = {
      id: "list_" + crypto.randomUUID(),
      userId: newUser.id,
      name: "My First Todo List",
      shareToken: crypto.randomUUID(),
      isPublic: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const token = crypto.randomUUID();
    db.users.push(newUser);
    db.lists.push(defaultList);
    db.tokens[token] = newUser.id;
    saveDB(db);

    return res.json({
      user: { id: newUser.id, name: newUser.name, email: newUser.email },
      token,
    });
  });

  app.post("/api/auth/login", (req: Request, res: Response) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const user = db.users.find((u) => u.email === email.toLowerCase().trim());
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const inputHash = hashPassword(password, user.salt);
    if (inputHash !== user.passwordHash) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = crypto.randomUUID();
    db.tokens[token] = user.id;
    saveDB(db);

    return res.json({
      user: { id: user.id, name: user.name, email: user.email },
      token,
    });
  });

  app.get("/api/auth/me", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = db.users.find((u) => u.id === req.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    return res.json({
      user: { id: user.id, name: user.name, email: user.email },
    });
  });

  // --- TODO LIST ENDPOINTS ---
  app.get("/api/lists", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const userLists = db.lists
      .filter((l) => l.userId === req.userId)
      .map((l) => {
        const itemCount = db.items.filter((item) => item.listId === l.id).length;
        return { ...l, itemCount };
      });
    return res.json(userLists);
  });

  app.post("/api/lists", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { name } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: "List name is required" });
    }

    const newList: ListData = {
      id: "list_" + crypto.randomUUID(),
      userId: req.userId!,
      name: name.trim(),
      shareToken: crypto.randomUUID(),
      isPublic: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.lists.push(newList);
    saveDB(db);
    return res.status(201).json({ ...newList, itemCount: 0 });
  });

  app.put("/api/lists/:id", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { name, isPublic } = req.body;

    const list = db.lists.find((l) => l.id === id && l.userId === req.userId);
    if (!list) {
      return res.status(404).json({ error: "List not found or permission denied" });
    }

    if (name !== undefined) list.name = name.trim();
    if (isPublic !== undefined) list.isPublic = Boolean(isPublic);
    list.updatedAt = new Date().toISOString();

    saveDB(db);
    const itemCount = db.items.filter((item) => item.listId === list.id).length;
    return res.json({ ...list, itemCount });
  });

  app.delete("/api/lists/:id", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const index = db.lists.findIndex((l) => l.id === id && l.userId === req.userId);
    if (index === -1) {
      return res.status(404).json({ error: "List not found or permission denied" });
    }

    // Delete list and associated items
    db.lists.splice(index, 1);
    db.items = db.items.filter((item) => item.listId !== id);
    saveDB(db);
    return res.json({ success: true, message: "List deleted successfully" });
  });

  // --- TODO ITEM ENDPOINTS ---
  app.get("/api/lists/:listId/items", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { listId } = req.params;
    const list = db.lists.find((l) => l.id === listId && l.userId === req.userId);
    if (!list) {
      return res.status(404).json({ error: "List not found" });
    }

    const items = db.items
      .filter((i) => i.listId === listId)
      .sort((a, b) => a.order - b.order);

    return res.json(items);
  });

  app.post("/api/lists/:listId/items", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { listId } = req.params;
    const { title, description, tags, dueDate, reminderEmail } = req.body;

    const list = db.lists.find((l) => l.id === listId && l.userId === req.userId);
    if (!list) {
      return res.status(404).json({ error: "List not found" });
    }

    if (!title || !title.trim()) {
      return res.status(400).json({ error: "Item title is required" });
    }

    const listItems = db.items.filter((i) => i.listId === listId);
    const maxOrder = listItems.length > 0 ? Math.max(...listItems.map((i) => i.order)) : -1;

    const newItem: ItemData = {
      id: "item_" + crypto.randomUUID(),
      listId,
      title: title.trim(),
      description: description ? description.trim() : undefined,
      completed: false,
      tags: Array.isArray(tags) ? tags.map((t: string) => t.trim().toLowerCase()).filter(Boolean) : [],
      order: maxOrder + 1,
      dueDate: dueDate || undefined,
      reminderEmail: reminderEmail ? reminderEmail.trim() : undefined,
      reminderSent: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.items.push(newItem);
    saveDB(db);
    return res.status(201).json(newItem);
  });

  app.put("/api/items/:id", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const item = db.items.find((i) => i.id === id);
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }

    // Verify user owns the list
    const list = db.lists.find((l) => l.id === item.listId && l.userId === req.userId);
    if (!list) {
      return res.status(403).json({ error: "Permission denied" });
    }

    const { title, description, completed, tags, dueDate, reminderEmail, order } = req.body;

    if (title !== undefined) item.title = title.trim();
    if (description !== undefined) item.description = description ? description.trim() : undefined;
    if (completed !== undefined) item.completed = Boolean(completed);
    if (tags !== undefined && Array.isArray(tags)) {
      item.tags = tags.map((t: string) => t.trim().toLowerCase()).filter(Boolean);
    }
    if (dueDate !== undefined) item.dueDate = dueDate || undefined;
    if (reminderEmail !== undefined) {
      item.reminderEmail = reminderEmail ? reminderEmail.trim() : undefined;
      item.reminderSent = false;
    }
    if (order !== undefined) item.order = Number(order);

    item.updatedAt = new Date().toISOString();
    saveDB(db);
    return res.json(item);
  });

  app.put("/api/lists/:listId/reorder", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { listId } = req.params;
    const { itemIds } = req.body; // Array of item IDs in new order

    const list = db.lists.find((l) => l.id === listId && l.userId === req.userId);
    if (!list) {
      return res.status(404).json({ error: "List not found" });
    }

    if (!Array.isArray(itemIds)) {
      return res.status(400).json({ error: "itemIds array required" });
    }

    itemIds.forEach((id: string, index: number) => {
      const item = db.items.find((i) => i.id === id && i.listId === listId);
      if (item) {
        item.order = index;
        item.updatedAt = new Date().toISOString();
      }
    });

    saveDB(db);
    const updatedItems = db.items
      .filter((i) => i.listId === listId)
      .sort((a, b) => a.order - b.order);

    return res.json(updatedItems);
  });

  app.delete("/api/items/:id", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const itemIndex = db.items.findIndex((i) => i.id === id);
    if (itemIndex === -1) {
      return res.status(404).json({ error: "Item not found" });
    }

    const item = db.items[itemIndex];
    const list = db.lists.find((l) => l.id === item.listId && l.userId === req.userId);
    if (!list) {
      return res.status(403).json({ error: "Permission denied" });
    }

    db.items.splice(itemIndex, 1);
    saveDB(db);
    return res.json({ success: true });
  });

  // --- PUBLIC SHARE ENDPOINT ---
  app.get("/api/shared/:shareToken", (req: Request, res: Response) => {
    const { shareToken } = req.params;
    const list = db.lists.find((l) => l.shareToken === shareToken);

    if (!list) {
      return res.status(404).json({ error: "Shared todo list not found" });
    }

    if (!list.isPublic) {
      return res.status(403).json({ error: "This todo list is private and not currently shared publicly." });
    }

    const owner = db.users.find((u) => u.id === list.userId);
    const items = db.items
      .filter((i) => i.listId === list.id)
      .sort((a, b) => a.order - b.order);

    // Compute statistics
    const total = items.length;
    const completed = items.filter((i) => i.completed).length;
    const pending = total - completed;
    const tagCounts: Record<string, number> = {};
    let noTagCount = 0;

    items.forEach((item) => {
      if (!item.tags || item.tags.length === 0) {
        noTagCount++;
      } else {
        item.tags.forEach((tag) => {
          tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        });
      }
    });

    return res.json({
      list: {
        id: list.id,
        name: list.name,
        shareToken: list.shareToken,
        isPublic: list.isPublic,
        createdAt: list.createdAt,
      },
      ownerName: owner ? owner.name : "Anonymous User",
      items,
      stats: {
        total,
        completed,
        pending,
        tagCounts,
        noTagCount,
      },
    });
  });

  // --- REMINDERS & SIMULATED EMAIL ENDPOINTS ---
  app.post("/api/reminders/trigger", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = db.users.find((u) => u.id === req.userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    const userListIds = db.lists.filter((l) => l.userId === req.userId).map((l) => l.id);
    const userItems = db.items.filter((i) => userListIds.includes(i.listId) && i.reminderEmail && !i.reminderSent && !i.completed);

    const triggeredLogs: ReminderLogData[] = [];

    userItems.forEach((item) => {
      const list = db.lists.find((l) => l.id === item.listId);
      item.reminderSent = true;
      const log: ReminderLogData = {
        id: "log_" + crypto.randomUUID(),
        userId: req.userId!,
        todoTitle: item.title,
        listName: list ? list.name : "Todo List",
        email: item.reminderEmail || user.email,
        sentAt: new Date().toISOString(),
      };
      db.reminderLogs.push(log);
      triggeredLogs.push(log);
    });

    saveDB(db);
    return res.json({ triggeredCount: triggeredLogs.length, logs: triggeredLogs });
  });

  app.get("/api/reminders/logs", requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const logs = db.reminderLogs
      .filter((log) => log.userId === req.userId)
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
    return res.json(logs);
  });

  // --- VITE / STATIC SERVING ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
