import React, { useState, useEffect } from "react";
import {
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Globe,
  Lock,
  ListTodo,
  Tag as TagIcon,
  RefreshCw,
  Sparkles,
  AlertCircle,
  X,
  Share2,
  Bell,
  Menu,
} from "lucide-react";
import { User, TodoList, TodoItem, ListStats } from "./types";
import { api, getStoredToken, setStoredToken } from "./services/api";
import { Navbar } from "./components/Navbar";
import { ListSidebar } from "./components/ListSidebar";
import { TodoStatsCard } from "./components/TodoStatsCard";
import { TodoItemRow } from "./components/TodoItemRow";
import { TagBadge } from "./components/TagBadge";
import { AuthModal } from "./components/AuthModal";
import { ShareModal } from "./components/ShareModal";
import { PublicView } from "./components/PublicView";
import { ReminderModal } from "./components/ReminderModal";

export default function App() {
  // Check URL query string for public shareToken
  const urlParams = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
  const initialShareToken = urlParams ? urlParams.get("shareToken") : null;

  const [shareTokenView, setShareTokenView] = useState<string | null>(initialShareToken);

  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Todo Lists & Items State
  const [lists, setLists] = useState<TodoList[]>([]);
  const [activeListId, setActiveListId] = useState<string | null>(null);
  const [items, setItems] = useState<TodoItem[]>([]);
  const [loadingLists, setLoadingLists] = useState(true);
  const [loadingItems, setLoadingItems] = useState(false);

  // Filter & Search
  const [selectedTagFilter, setSelectedTagFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // New Item Input State
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState("");
  const [newItemDesc, setNewItemDesc] = useState("");
  const [newItemTags, setNewItemTags] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState("");
  const [newItemDueDate, setNewItemDueDate] = useState("");
  const [newItemReminderEmail, setNewItemReminderEmail] = useState("");

  // Modals & Drawers
  const [sharingList, setSharingList] = useState<TodoList | null>(null);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // 1. Initial Load: Auth check and fetch lists
  useEffect(() => {
    const initApp = async () => {
      const token = getStoredToken();
      if (token) {
        try {
          const res = await api.getMe();
          setUser(res.user);
        } catch (err) {
          console.error("Session expired:", err);
          setStoredToken(null);
        }
      }
      fetchLists();
    };

    initApp();
  }, []);

  // 2. Fetch Todo Lists
  const fetchLists = async () => {
    setLoadingLists(true);
    try {
      const res = await api.getLists();
      setLists(res);
      if (res.length > 0 && !activeListId) {
        setActiveListId(res[0].id);
      }
    } catch (err) {
      console.error("Failed to fetch lists:", err);
    } finally {
      setLoadingLists(false);
    }
  };

  // 3. Fetch Items when activeListId changes
  useEffect(() => {
    if (!activeListId) {
      setItems([]);
      return;
    }

    const fetchItems = async () => {
      setLoadingItems(true);
      try {
        const res = await api.getItems(activeListId);
        setItems(res);
      } catch (err) {
        console.error("Failed to fetch items:", err);
      } finally {
        setLoadingItems(false);
      }
    };

    fetchItems();
  }, [activeListId]);

  // Compute Statistics per Todo List
  const computeStats = (): ListStats => {
    const total = items.length;
    const completed = items.filter((i) => i.completed).length;
    const pending = total - completed;
    const tagCounts: Record<string, number> = {};
    let noTagCount = 0;

    items.forEach((item) => {
      if (!item.tags || item.tags.length === 0) {
        noTagCount++;
      } else {
        item.tags.forEach((tag) => {
          tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        });
      }
    });

    return {
      total,
      completed,
      pending,
      tagCounts,
      noTagCount,
    };
  };

  const activeList = lists.find((l) => l.id === activeListId) || null;

  // --- LIST HANDLERS ---
  const handleCreateList = async (name: string) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    try {
      const newList = await api.createList(name);
      setLists([...lists, newList]);
      setActiveListId(newList.id);
    } catch (err: any) {
      alert(err.message || "Failed to create list");
    }
  };

  const handleRenameList = async (id: string, newName: string) => {
    try {
      const updated = await api.updateList(id, { name: newName });
      setLists(lists.map((l) => (l.id === id ? updated : l)));
    } catch (err: any) {
      alert(err.message || "Failed to rename list");
    }
  };

  const handleDeleteList = async (id: string) => {
    try {
      await api.deleteList(id);
      const remaining = lists.filter((l) => l.id !== id);
      setLists(remaining);
      if (activeListId === id) {
        setActiveListId(remaining.length > 0 ? remaining[0].id : null);
      }
    } catch (err: any) {
      alert(err.message || "Failed to delete list");
    }
  };

  const handleTogglePublicShare = async (id: string, isPublic: boolean) => {
    try {
      const updated = await api.updateList(id, { isPublic });
      setLists(lists.map((l) => (l.id === id ? updated : l)));
      if (sharingList && sharingList.id === id) {
        setSharingList(updated);
      }
    } catch (err: any) {
      alert(err.message || "Failed to update list share status");
    }
  };

  // --- TODO ITEM HANDLERS ---
  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeListId) return;
    if (!newItemTitle.trim()) return;

    try {
      const created = await api.createItem(activeListId, {
        title: newItemTitle.trim(),
        description: newItemDesc.trim() || undefined,
        tags: newItemTags,
        dueDate: newItemDueDate || undefined,
        reminderEmail: newItemReminderEmail.trim() || undefined,
      });

      setItems([...items, created]);
      // Reset form
      setNewItemTitle("");
      setNewItemDesc("");
      setNewItemTags([]);
      setNewItemDueDate("");
      setNewItemReminderEmail("");
      setIsAddingItem(false);

      // Update list count in sidebar
      setLists(
        lists.map((l) =>
          l.id === activeListId ? { ...l, itemCount: (l.itemCount || 0) + 1 } : l
        )
      );
    } catch (err: any) {
      alert(err.message || "Failed to add todo item");
    }
  };

  const handleToggleComplete = async (item: TodoItem) => {
    try {
      const updated = await api.updateItem(item.id, {
        completed: !item.completed,
      });
      setItems(items.map((i) => (i.id === item.id ? updated : i)));
    } catch (err: any) {
      alert(err.message || "Failed to update item");
    }
  };

  const handleUpdateItem = async (item: TodoItem, updates: Partial<TodoItem>) => {
    try {
      const updated = await api.updateItem(item.id, updates);
      setItems(items.map((i) => (i.id === item.id ? updated : i)));
    } catch (err: any) {
      alert(err.message || "Failed to save item edits");
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    try {
      await api.deleteItem(itemId);
      setItems(items.filter((i) => i.id !== itemId));
      if (activeListId) {
        setLists(
          lists.map((l) =>
            l.id === activeListId
              ? { ...l, itemCount: Math.max(0, (l.itemCount || 1) - 1) }
              : l
          )
        );
      }
    } catch (err: any) {
      alert(err.message || "Failed to delete item");
    }
  };

  // Reordering Move Up / Down
  const handleMoveItem = async (index: number, direction: "up" | "down") => {
    if (!activeListId) return;
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= items.length) return;

    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[targetIndex];
    newItems[targetIndex] = temp;

    setItems(newItems);

    try {
      const itemIds = newItems.map((i) => i.id);
      await api.reorderItems(activeListId, itemIds);
    } catch (err: any) {
      console.error("Failed to reorder items:", err);
    }
  };

  // Filter items by tag filter and search query
  const filteredItems = items.filter((item) => {
    // Search Filter
    if (
      searchQuery &&
      !item.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !(item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }

    // Tag Filter
    if (!selectedTagFilter) return true;
    if (selectedTagFilter === "no tag") {
      return !item.tags || item.tags.length === 0;
    }
    return item.tags && item.tags.includes(selectedTagFilter);
  });

  // If public shareToken URL parameter is active, display PublicView component
  if (shareTokenView) {
    return (
      <PublicView
        shareToken={shareTokenView}
        onGoHome={() => {
          setShareTokenView(null);
          window.history.pushState({}, "", window.location.pathname);
        }}
      />
    );
  }

  const stats = computeStats();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      {/* Top Header Navbar */}
      <Navbar
        user={user}
        activeList={activeList}
        onOpenAuth={() => setShowAuthModal(true)}
        onLogout={() => {
          setStoredToken(null);
          setUser(null);
          fetchLists();
        }}
        onOpenShareModal={() => activeList && setSharingList(activeList)}
        onOpenReminders={() => setShowReminderModal(true)}
        onToggleMobileDrawer={() => setIsMobileDrawerOpen(!isMobileDrawerOpen)}
        onQuickAddItem={() => setIsAddingItem(true)}
      />

      {/* Main Container Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col md:flex-row">
        {/* Desktop Sidebar */}
        <aside className="hidden md:block w-72 shrink-0 border-r border-slate-200 dark:border-slate-800">
          <ListSidebar
            lists={lists}
            activeListId={activeListId}
            onSelectList={setActiveListId}
            onCreateList={handleCreateList}
            onRenameList={handleRenameList}
            onDeleteList={handleDeleteList}
            onOpenShareModal={(list) => setSharingList(list)}
          />
        </aside>

        {/* Mobile Slide-out Drawer */}
        {isMobileDrawerOpen && (
          <div className="md:hidden fixed inset-0 z-40 flex">
            <div
              onClick={() => setIsMobileDrawerOpen(false)}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            />
            <div className="relative w-80 max-w-[85%] bg-white dark:bg-slate-900 h-full z-50">
              <ListSidebar
                lists={lists}
                activeListId={activeListId}
                onSelectList={setActiveListId}
                onCreateList={handleCreateList}
                onRenameList={handleRenameList}
                onDeleteList={handleDeleteList}
                onOpenShareModal={(list) => setSharingList(list)}
                onCloseMobileDrawer={() => setIsMobileDrawerOpen(false)}
              />
            </div>
          </div>
        )}

        {/* Primary Todo Workspace */}
        <main className="flex-1 p-4 sm:p-6 md:p-8 min-w-0">
          {activeList ? (
            <div>
              {/* Active List Title & Quick Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
                      {activeList.name}
                    </h1>
                    {activeList.isPublic ? (
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                        <Globe className="w-3.5 h-3.5" />
                        <span>Publicly Shared</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 rounded-full">
                        <Lock className="w-3.5 h-3.5" />
                        <span>Private</span>
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Manage tasks, assign tags, track progress stats, and generate public share links.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSharingList(activeList)}
                    className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-indigo-500" />
                    <span>Share List</span>
                  </button>

                  <button
                    onClick={() => setIsAddingItem(!isAddingItem)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                    <span>Add Task</span>
                  </button>
                </div>
              </div>

              {/* Statistics Panel with Tag Filtering */}
              <TodoStatsCard
                stats={stats}
                selectedTagFilter={selectedTagFilter}
                onSelectTagFilter={setSelectedTagFilter}
                listName={activeList.name}
              />

              {/* Inline Add Item Card */}
              {isAddingItem && (
                <form
                  onSubmit={handleAddItem}
                  className="bg-white dark:bg-slate-900 border-2 border-indigo-500/40 rounded-2xl p-5 shadow-md mb-6 space-y-4 animate-fade-in"
                >
                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                      <Plus className="w-4 h-4" />
                      <span>Create Todo Item</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAddingItem(false)}
                      className="text-slate-400 hover:text-slate-600 p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Task Title *
                    </label>
                    <input
                      type="text"
                      autoFocus
                      required
                      value={newItemTitle}
                      onChange={(e) => setNewItemTitle(e.target.value)}
                      placeholder="e.g. Implement tag filter component"
                      className="w-full text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Description (Optional)
                    </label>
                    <textarea
                      value={newItemDesc}
                      onChange={(e) => setNewItemDesc(e.target.value)}
                      rows={2}
                      placeholder="Add extra context or instructions..."
                      className="w-full text-xs px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  {/* Tags Selector */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Tags (e.g. urgent, not important, low priority)
                    </label>
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {newItemTags.map((tag) => (
                        <TagBadge
                          key={tag}
                          tag={tag}
                          size="sm"
                          onRemove={() => setNewItemTags(newItemTags.filter((t) => t !== tag))}
                        />
                      ))}
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newTagInput}
                        onChange={(e) => setNewTagInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            if (newTagInput.trim() && !newItemTags.includes(newTagInput.trim().toLowerCase())) {
                              setNewItemTags([...newItemTags, newTagInput.trim().toLowerCase()]);
                              setNewTagInput("");
                            }
                          }
                        }}
                        placeholder="Add tag and press Enter..."
                        className="flex-1 text-xs px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newTagInput.trim() && !newItemTags.includes(newTagInput.trim().toLowerCase())) {
                            setNewItemTags([...newItemTags, newTagInput.trim().toLowerCase()]);
                            setNewTagInput("");
                          }
                        }}
                        className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 text-xs font-semibold rounded-lg hover:bg-slate-300"
                      >
                        Add Tag
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-2">
                      <span className="text-[11px] text-slate-400 self-center mr-1">Presets:</span>
                      {["urgent", "high priority", "low priority", "not important", "work", "personal"].map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => {
                            if (!newItemTags.includes(t)) {
                              setNewItemTags([...newItemTags, t]);
                            }
                          }}
                          className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-indigo-50 hover:text-indigo-600"
                        >
                          +{t}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Due Date & Email Reminder */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Due Date
                      </label>
                      <input
                        type="date"
                        value={newItemDueDate}
                        onChange={(e) => setNewItemDueDate(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Email Reminder Alert
                      </label>
                      <input
                        type="email"
                        value={newItemReminderEmail}
                        onChange={(e) => setNewItemReminderEmail(e.target.value)}
                        placeholder="user@example.com"
                        className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingItem(false)}
                      className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs"
                    >
                      Create Task
                    </button>
                  </div>
                </form>
              )}

              {/* Task Search Bar */}
              <div className="mb-4 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tasks by name or description..."
                  className="w-full text-xs pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
                />
              </div>

              {/* Todo Items Collection */}
              <div className="space-y-2">
                {loadingItems ? (
                  <div className="py-12 text-center text-slate-400 flex flex-col items-center gap-2">
                    <RefreshCw className="w-6 h-6 animate-spin text-indigo-500" />
                    <span className="text-xs">Loading items...</span>
                  </div>
                ) : filteredItems.length === 0 ? (
                  <div className="py-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-8">
                    <ListTodo className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
                    <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                      No tasks found
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      {selectedTagFilter
                        ? `No tasks with tag #${selectedTagFilter}. Click 'Show All' in the stats card above.`
                        : "Your list is empty. Click 'Add Task' to create your first todo item!"}
                    </p>
                    {!isAddingItem && (
                      <button
                        onClick={() => setIsAddingItem(true)}
                        className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl inline-flex items-center gap-1.5 shadow-xs"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add First Task</span>
                      </button>
                    )}
                  </div>
                ) : (
                  filteredItems.map((item, index) => (
                    <TodoItemRow
                      key={item.id}
                      item={item}
                      index={index}
                      totalItems={filteredItems.length}
                      onToggleComplete={handleToggleComplete}
                      onUpdateItem={handleUpdateItem}
                      onDeleteItem={handleDeleteItem}
                      onMoveUp={() => handleMoveItem(index, "up")}
                      onMoveDown={() => handleMoveItem(index, "down")}
                    />
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="py-20 text-center">
              <Sparkles className="w-12 h-12 text-indigo-500 mx-auto mb-3" />
              <h2 className="text-lg font-bold text-slate-800 dark:text-slate-200">
                Welcome to TaskMaster
              </h2>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
                Select a Todo List from the sidebar or create a new one to start managing tasks.
              </p>
              <button
                onClick={() => handleCreateList("My Tasks")}
                className="px-4 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700"
              >
                Create First Todo List
              </button>
            </div>
          )}
        </main>
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={(loggedInUser) => {
            setUser(loggedInUser);
            setShowAuthModal(false);
            fetchLists();
          }}
        />
      )}

      {/* Share Modal */}
      {sharingList && (
        <ShareModal
          list={sharingList}
          onClose={() => setSharingList(null)}
          onTogglePublic={handleTogglePublicShare}
        />
      )}

      {/* Email Reminders Modal */}
      {showReminderModal && (
        <ReminderModal onClose={() => setShowReminderModal(false)} />
      )}
    </div>
  );
}
