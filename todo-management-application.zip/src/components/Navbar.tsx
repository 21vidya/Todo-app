import React from "react";
import {
  CheckSquare,
  Menu,
  Share2,
  Bell,
  LogIn,
  LogOut,
  User as UserIcon,
  Globe,
  Plus,
} from "lucide-react";
import { User, TodoList } from "../types";

interface NavbarProps {
  user: User | null;
  activeList: TodoList | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenShareModal: () => void;
  onOpenReminders: () => void;
  onToggleMobileDrawer: () => void;
  onQuickAddItem: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeList,
  onOpenAuth,
  onLogout,
  onOpenShareModal,
  onOpenReminders,
  onToggleMobileDrawer,
  onQuickAddItem,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* Left Section: Mobile Menu & Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileDrawer}
            className="md:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            title="Toggle Todo Lists Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <span className="font-black text-slate-900 dark:text-slate-100 text-base tracking-tight block leading-none">
                TaskMaster
              </span>
              <span className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                Todo Application
              </span>
            </div>
          </div>
        </div>

        {/* Center Active List Badge */}
        {activeList && (
          <div className="hidden sm:flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {activeList.name}
            </span>
            {activeList.isPublic && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                <Globe className="w-3 h-3" />
                <span>Publicly Shared</span>
              </span>
            )}
          </div>
        )}

        {/* Right Section Actions */}
        <div className="flex items-center gap-2">
          {activeList && (
            <button
              onClick={onQuickAddItem}
              className="p-2 sm:px-3 sm:py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              title="Add Todo Item"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Task</span>
            </button>
          )}

          {activeList && (
            <button
              onClick={onOpenShareModal}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              title="Share Todo List"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onOpenReminders}
            className="p-2 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/50 rounded-xl transition-colors cursor-pointer"
            title="Email Reminders"
          >
            <Bell className="w-4 h-4" />
          </button>

          {/* User Account Button */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-xl">
                <UserIcon className="w-3.5 h-3.5 text-indigo-500" />
                <span className="max-w-[100px] truncate">{user.name}</span>
              </div>
              <button
                onClick={onLogout}
                className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-lg transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-semibold text-xs rounded-xl hover:bg-indigo-100 dark:hover:bg-indigo-900/60 flex items-center gap-1.5 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In / Register</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
