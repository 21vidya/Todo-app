import React, { useState, useEffect } from "react";
import { Bell, Mail, Send, CheckCircle, Clock, RefreshCw, X } from "lucide-react";
import { ReminderLog } from "../types";
import { api } from "../services/api";

interface ReminderModalProps {
  onClose: () => void;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({ onClose }) => {
  const [logs, setLogs] = useState<ReminderLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const res = await api.getReminderLogs();
      setLogs(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleTriggerReminders = async () => {
    setTriggering(true);
    setStatusMessage(null);
    try {
      const res = await api.triggerReminders();
      if (res.triggeredCount > 0) {
        setStatusMessage(`Successfully sent ${res.triggeredCount} email reminder(s)!`);
        fetchLogs();
      } else {
        setStatusMessage("No pending reminders due at this moment.");
      }
    } catch (err: any) {
      setStatusMessage("Failed to send reminders: " + err.message);
    } finally {
      setTriggering(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              Email Reminders Center
            </h3>
            <p className="text-xs text-slate-500">
              Set email alerts on tasks and check notification logs
            </p>
          </div>
        </div>

        {/* Trigger Test Email Button */}
        <div className="p-4 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900 mb-5 flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
              Check & Trigger Pending Email Reminders
            </h4>
            <p className="text-[11px] text-indigo-700/80 dark:text-indigo-300 mt-0.5">
              Simulates sending email alerts for tasks with reminders.
            </p>
          </div>

          <button
            onClick={handleTriggerReminders}
            disabled={triggering}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer disabled:opacity-50"
          >
            {triggering ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            <span>Trigger Now</span>
          </button>
        </div>

        {statusMessage && (
          <div className="mb-4 p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs rounded-xl flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Reminder Delivery History Logs */}
        <div>
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center justify-between">
            <span>Sent Email Reminder Logs ({logs.length})</span>
            <button onClick={fetchLogs} className="text-[11px] text-indigo-600 hover:underline">
              Refresh
            </button>
          </h4>

          <div className="max-h-52 overflow-y-auto space-y-2 pr-1">
            {loading ? (
              <div className="py-8 text-center text-xs text-slate-400">Loading logs...</div>
            ) : logs.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed">
                <Clock className="w-6 h-6 mx-auto mb-1 opacity-40" />
                <span>No email reminders sent yet. Assign email reminders to your todo items!</span>
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 text-xs flex items-start justify-between gap-2"
                >
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-100">
                      "{log.todoTitle}"
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <Mail className="w-3 h-3 text-slate-400" />
                      <span>To: {log.email}</span>
                      <span>• List: {log.listName}</span>
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-400 whitespace-nowrap">
                    {new Date(log.sentAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
